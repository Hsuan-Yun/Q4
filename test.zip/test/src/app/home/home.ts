import { Component, inject, OnInit, signal } from '@angular/core';
import { HomeService } from './service/home.service';
import { Item } from './home.model';

@Component({
  imports: [],
  selector: 'app-home',
  styleUrl: './home.css',
  templateUrl: './home.html',
})
export class Home implements OnInit {
  protected home = inject(HomeService);

  itemList: Item[] = [];
  // itemList = signal<Item[]>([]);

  ngOnInit(): void {
    this.home.getMenu().subscribe({
      next: (data) => {
        this.itemList = data;
        console.log(this.itemList);
        // this.itemList.set(data);
        // console.log(this.itemList);
        // console.log(this.itemList());
      },
      error: (error) => {
        console.error('Failed to load menu:', error);
      },
    });
  }
}
