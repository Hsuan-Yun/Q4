import { HttpClient } from '@angular/common/http';
import { inject, Service } from '@angular/core';
import { Item } from '../home.model';

@Service()
export class HomeService {
  protected http = inject(HttpClient);

  getMenu() {
    return this.http.get<Item[]>('/menu.json');
  }
}
